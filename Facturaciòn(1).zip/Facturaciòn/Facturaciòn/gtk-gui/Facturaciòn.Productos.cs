
namespace Facturaciòn
{
	public partial class Productos
	{
		private void Build()
		{
		}
	}
}
