
namespace Facturaciòn
{
	public partial class Clientes
	{
		private void Build()
		{
		}
	}
}
