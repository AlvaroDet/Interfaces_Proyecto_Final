
namespace Facturaciòn
{
	public partial class ProductoTienda
	{
		private void Build()
		{
		}
	}
}
