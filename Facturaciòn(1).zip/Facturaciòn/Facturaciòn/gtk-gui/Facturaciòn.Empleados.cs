
namespace Facturaciòn
{
	public partial class Empleados
	{
		private void Build()
		{
		}
	}
}
