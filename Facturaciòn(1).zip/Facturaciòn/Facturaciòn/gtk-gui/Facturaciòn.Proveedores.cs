
namespace Facturaciòn
{
	public partial class Proveedores
	{
		private void Build()
		{
		}
	}
}
