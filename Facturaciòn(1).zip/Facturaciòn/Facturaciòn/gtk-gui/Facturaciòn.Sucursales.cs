
namespace Facturaciòn
{
	public partial class Sucursales
	{
		private void Build()
		{
		}
	}
}
