﻿using System;
namespace Facturaciòn
{
    public partial class Proveedores : Gtk.Window
    {
        public Proveedores() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
