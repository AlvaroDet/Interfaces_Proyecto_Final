﻿using System;
namespace Facturaciòn
{
    public partial class Inicio : Gtk.Window
    {
        public Inicio() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
