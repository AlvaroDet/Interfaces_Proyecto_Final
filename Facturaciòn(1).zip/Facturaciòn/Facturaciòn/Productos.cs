﻿using System;
namespace Facturaciòn
{
    public partial class Productos : Gtk.Window
    {
        public Productos() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
