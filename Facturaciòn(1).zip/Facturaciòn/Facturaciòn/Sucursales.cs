﻿using System;
namespace Facturaciòn
{
    public partial class Sucursales : Gtk.Window
    {
        public Sucursales() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
