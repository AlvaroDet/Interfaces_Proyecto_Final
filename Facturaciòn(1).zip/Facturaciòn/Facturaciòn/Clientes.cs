﻿using System;
namespace Facturaciòn
{
    public partial class Clientes : Gtk.Window
    {
        public Clientes() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
