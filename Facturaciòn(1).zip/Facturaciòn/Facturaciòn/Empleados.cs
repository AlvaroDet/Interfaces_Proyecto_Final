﻿using System;
namespace Facturaciòn
{
    public partial class Empleados : Gtk.Window
    {
        public Empleados() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
